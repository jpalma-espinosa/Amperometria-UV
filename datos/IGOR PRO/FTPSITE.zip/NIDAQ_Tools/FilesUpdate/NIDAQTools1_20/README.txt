WELCOME
  The files in this directory contain the NIDAQ Tools package version 1.20. These
  files are made available for those who already own NIDAQ Tools- they are
  password-protected.
  
  Version 1.2 of NIDAQ Tools requires Igor Pro 3.13 or later. If you are running
  Igor Pro 3.10-3.12, you can get a free updater for version 3.13. See the directory
  IgorPro/FilesUpdate/.

INSTALLING NIDAQ Tools- Windows

 If you use NIDAQ Tools on Windows, you should download the file NIDAQTools_1_20_Win.EXE.
 
 This is a self-extracting WinZip file. Double-click the file, and enter the path to your
 Igor Pro folder in the "Unzip To Folder:" box. It is pre-loaded with the default
 Igor Pro Folder path. When you click Unzip, all the files and folders are installed in
 the correct places in your Igor Pro folder.

INSTALLING NIDAQ Tools- Macintosh

 If you use NIDAQ Tools on a Macintosh, you should download the file NIDAQTools_1_20_Mac.sit.
 
 This is a StuffIt archive; you will need StuffIt Expander or StuffIt Deluxe to unpack the
 file. When expanded, it will make a folder containing folders with names like
 "copy to Igor Help Files folder". Just follow the directions, copying the various files or
 folders into your Igor Pro Folder. More detailed instructions are available in the manual,
 which is included in PDF format (see below).
 
 There are two versions of the NIDAQ XOP file for Macintosh- NIDAQ and NIDAQ60.
 **You must install only one**. Consult the manual to decide which to use.
 
ONLINE MANUAL
  This distribution of NIDAQ Tools includes a Portable Document Format (PDF)
  version of the manual in the folder NIDAQ Manual.

  To use the online manual you will need Adobe Acrobat Reader 3.01 or
  later. You can download Acrobat Reader free from Adobe:
  
    http://www.adobe.com/prodindex/acrobat/readstep.html

TAKE THE GUIDED TOUR
  The NIDAQ Tools manual includes a Guided Tour in Chapter 2. We 
  recommend it to you!

SYSTEM REQUIREMENTS
  Igor Pro and NIDAQ Tools require system 7.0.0 or later and also requires
  a 68020 CPU or better. NIDAQ Tools requires Igor Pro 3.13 or later. 

  If you have an earlier version of Igor Pro, you must update. See our web
  page for free update information: http://www.wavemetrics.com/

  If your version of Igor is earlier than 3.1, contact WaveMetrics, Inc. for
  information about our low-cost upgrades. 

FEEDBACK & SALES CONTACTS
  We welcome feedback at any time and we do take it seriously.

  You may contact us at these email addresses:
            sales@wavemetrics.com
            support@wavemetrics.com

  Our telephone number is (503) 620-3001, and our FAX number is (503) 620-6754.

GETTING IGOR NEWS
  There are several ways to keep up with the latest Igor news and
  get the latest tech notes and what-not.

    Igor Mailing List
        To subscribe (or unsubscribe), send email to:
               igor-request@pica.army.mil.
        Send articles (questions/comments) to:
               igor@pica.army.mil.

  NOTE: Please use igor-request to subscribe or unsubscribe. Any mail
        that you send to igor@pica.army.mil goes to all subscribers.

    FTP
    There are several FTP sites containing Igor-related files.
    The d31rz0 site is the main site and gets files before the others.
    Note: d31rz0 is dee-three-one-ar-zee-zero.

    Main FTP site:             ftp://d31rz0.stanford.edu/WaveMetrics/
    U.S.A. FTP mirror:       ftp://phadmin.physics.gatech.edu/WaveMetrics/
    Asian FTP mirror:       ftp://ftp.eos.hokudai.ac.jp/pub/mac/WaveMetrics/
    European FTP mirror:  ftp://igor.rz-berlin.mpg.de/pub/WaveMetrics/

  WorldWide Web
     Check out our Web site: http://www.wavemetrics.com/


WELCOME
  Thankyou for trying the NIDAQ Tools demo. This demo will work for 30 days
  from the time you first run it after which it will refuse to work. Otherwise, 
  it is identical to the shipping NIDAQ Tools package.

  This is version 1.21 Demo of NIDAQ Tools, and requires Igor Pro 3.13 or later.

INSTALLING NIDAQ Tools
  Download the file the file NIDAQ Demo1_21.exe to your desktop, then 
  double-click the file. It opens up a window in which you must enter the path
  to your Igor Pro folder. It is set by default to 
  C:\Program Files\WaveMetrics\Igor Pro Folder\ since this is the default
  installation location used by the Igor Pro installer. If your Igor Pro folder
  is in a different place, you must edit the path.

ONLINE MANUAL
  This demo package includes the full NIDAQ Tools manual in electronic form. 
  Double-click the NIDAQTls.pdf in the NIDAQ Manual folder. This is an Adobe 
  Acrobat Portable Document  Format or PDF file.

  To use the online manual you will need Adobe Acrobat Reader 3.01 or
  later. If you don't have Acrobat Reader 3.01, you can download it from
  http://www.adobe.com. Click the button labelled "Get Acrobat Reader".

TAKE THE GUIDED TOUR
  The NIDAQ Tools manual includes a Guided Tour in Chapter 2. We 
  recommend it to you!

REMOVING NIDAQ Tools
  There is no un-installer for the NIDAQ Tools package. To remove NIDAQ Tools
  you must trash the various files that were installed. These items were
  installed when you installed NIDAQ Tools:

  NIDAQ.xop file was installed in the Igor Extensions folder.
  These files were installed in the Igor Help Files folder:
    NIDAQ Help.ihf
    NIDAQ Help.ihf.igr
    NIDAQ Reference.ihf
    NIDAQ Reference.ihf.igr
  Four folders were installed in the Igor Pro folder:
    NIDAQ Manual
    NIDAQ Configurations
    NIDAQ Procedures
    NIDAQ Additional Help Files

SYSTEM REQUIREMENTS
  Igor Pro and NIDAQ Tools require Windows 95/98/NT4 or later. NIDAQ Tools 
  *requires* Igor Pro 3.13 or later. 

  If you have an earlier version of Igor Pro, you must update. See our web
  page for free update information: http://www.wavemetrics.com/

  If your version of Igor is earlier than 3.1, contact WaveMetrics, Inc. for
  information about our low-cost upgrades. 

FEEDBACK & SALES CONTACTS
  We welcome feedback at any time and we do take it seriously.

  You may contact us at these email addresses:
            sales@wavemetrics.com
            support@wavemetrics.com

  Our telephone number is (503) 620-3001, and our FAX number is (503) 620-6754.

GETTING IGOR NEWS
  There are several ways to keep up with the latest Igor news and
  get the latest tech notes and what-not.

    Igor Mailing List
        To subscribe (or unsubscribe), send email to:
               igor-request@pica.army.mil.
        Send articles (questions/comments) to:
               igor@pica.army.mil.

  NOTE: Please use igor-request to subscribe or unsubscribe. Any mail
        that you send to igor@pica.army.mil goes to all subscribers.

    FTP
    There are several FTP sites containing Igor-related files.
    The d31rz0 site is the main site and gets files before the others.
    Note: d31rz0 is dee-three-one-ar-zee-zero.

    Main FTP site:             ftp://d31rz0.stanford.edu/WaveMetrics/
    U.S.A. FTP mirror:       ftp://phadmin.physics.gatech.edu/WaveMetrics/
    Asian FTP mirror:       ftp://ftp.eos.hokudai.ac.jp/pub/mac/WaveMetrics/
    European FTP mirror:  ftp://igor.rz-berlin.mpg.de/pub/WaveMetrics/

  WorldWide Web
     Check out our Web site: http://www.wavemetrics.com/


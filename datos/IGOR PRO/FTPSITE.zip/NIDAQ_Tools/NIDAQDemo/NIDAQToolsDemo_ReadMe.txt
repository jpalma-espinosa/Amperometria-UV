The NIDAQ Tools package adds support for data acquisition directly 
into IGOR Pro, the scientific analysis and graphing application for 
the Macintosh made by WaveMetrics, Inc.  IGOR Pro can take you from 
data acquisition, through analysis, to creation of publication-quality 
graphics.  The NIDAQ Tools package can be used with a variety of
data acquisition boards from National Instruments.  This includes
nearly all the cards that National Instruments calls "Multifunction
Data Acquisition boards", such as the PCI-MIO16XE series, the 1200
series and the DAQCard boards.

The NIDAQ Tools demo is fully functional; you can do anything with it 
that you can do with a purchased copy.  It will simply stop working 
after 30 days.  After that, it will not load into Igor Pro.

There are demo versions here for both Windows/95/98/NT4, and for
Macintosh. Open the appropriate directory and follow the instructions
in the README file that you find there.

The NIDAQ Tools require IGOR Pro to run.  If you do not own IGOR Pro, you
can get a demo version of IGOR Pro from this ftp site.  It is in the directory
/IgorPro/Demo.  The NIDAQ Tools will run just fine with the IGOR Pro demo.

You can purchase the NIDAQ Tools from WaveMetrics.  To place an
order, or to get more information, contact WaveMetrics as follows:

  e-mail:
     sales:                  sales@wavemetrics.com
     automated info:   info@wavemetrics.com
     technical info:     support@wavemetrics.com

  web page:               <URL:http://www.wavemetrics.com/>

	telephone:              (503) 620-3001
  fax:                        (503) 620-6754

  mail:                      WaveMetrics, Inc.
                                P.O. Box 2088
                                Lake Oswego, OR 97035
                                USA
Welcome to the Igor Filter Design Laboratory (IFDL) Demo!

  This demo version of IFDL allows you to design your own Kaiser
  Low Pass filters and other Window Filters, and apply them to your data.

  You can compare the responses of two filters, save the filter
  coefficients for use in other programs, and print a report
  showing a filter's response and coefficient values.

  Pre-computed examples of McClellan-Parks-Rabiner (MPR) filters
  and Kaiser Maximal Flatness filters are provided.

  This demo version ignores changes to the design parameters for
  these filter types.

  Purchase IFDL to enable the Kaiser Maximally Flat and all
  the MPR filters, and to receive a full electronic and printed manual.

  You can purchase IFDL from WaveMetrics, Inc. by calling (503)-620-3001,
  or by email at sales@wavemetrics.com.

  As of June 1998, pricing for IFDL 3.1 is $150.00 plus shipping.
  Upgrades from any previous version of IFDL are $50.00 plus shipping.

INSTALLING the IFDL Demo
  The IFDL Demo is comprised of a sample experiment and a number
  of procedure files.
  
  To install the procedures, copy the IFDL Procedures folder into
  your Igor Pro Folder.

SYSTEM REQUIREMENTS
  IFDL requires Igor Pro 3.12 or later. If your version of Igor is earlier
  earlier than 3.12, contact WaveMetrics, Inc. for information about our
  low-cost upgrades. 

FEEDBACK & SALES CONTACTS
  We welcome feedback at any time and we do take it seriously.

  You may contact us at these email addresses:
            sales@wavemetrics.com
            support@wavemetrics.com

  Our telephone number is (503)-620-3001, and our FAX number is (503)-620-6754.

  Check out our Web site: http://www.wavemetrics.com/


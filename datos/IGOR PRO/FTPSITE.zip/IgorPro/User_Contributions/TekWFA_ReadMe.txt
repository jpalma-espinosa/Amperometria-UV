Use these Igor Pro 3 procedures to load the *.WFA ASCII files created
by software associated with Tektronix's DSA601 and DSA602A digital
signal analyzers. 

The procedures aren't very fast, but they DO work.

To use the procedures...

Move to your User Procedures folder:
	Load Tek WFA File
	File Name Utilities
	Keyword-Value Generalized

Use the LoadTekWFAFile() macro to select a file to load and display.

If you move this file to your Igor Procedures folder:
	Tek WFA Drag & Drop

then you can drag .WFA files onto the Igor icon and they'll automatically be
loaded and displayed.


(Jim Prouty) jim@wavemetrics.com
WaveMetrics, Inc.
3/12/98


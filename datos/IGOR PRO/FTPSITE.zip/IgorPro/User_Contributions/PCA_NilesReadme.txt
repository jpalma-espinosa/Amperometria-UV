PCA_Niles.sit.hqx
PCA_Niles.zip

Introduction:
These procedures perform Principal Component Analysis (PCA) and
Target Factor Analysis (TFA).

The Idea of PCA to take a set of related waves, and let the computer
determine the number of distinct components comprising the wave set.

The Idea of TFA is that once we have a set of principal components,
we can make a physically reasonable set from them by a suitable transformation.

An example use is to compute depth profiles in electron spectroscopy.

David W. Niles
Agilent Technologies, Innovating the HP Way.
August 1999. 
david_niles@hp.com


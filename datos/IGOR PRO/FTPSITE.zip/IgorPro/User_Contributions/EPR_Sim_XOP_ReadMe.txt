Date: Tue, 20 Jun 1995 17:56:32 +48000
From: John Boswell <boswell@amethyst.cbs.ogi.edu>
To: eprlist <epr-list@xenon.che.ilstu.edu>, igorlist <igor@pica.army.mil>
Subject: EPR Simulation XOP available
Mime-Version: 1.0

Hi,
        This is a note to let people know that I've developed an XOP (external 
operation) for the Macintosh graphing and numerical analysis program, Igor 
Pro.  EPRSim XOP implements the QPOW powder EPR simulation code, and can 
also generate isotropic spectra.  I've successfully used the XOP to simulate 
the spectrum of PHM (a type-II copper protein), as well as the spectrum 
of a DMPO-S (thiyl) radical (spin trapped).
        The XOP appears to be stable, so I'm releasing it as "version 
1.0".  If you download the xop, please let me know what you think of it, 
and what I can do to improve it.

I've also put together a demo experiment that shows how to use the 
simulation routines, and gives sample input and output.

You can find the XOP and demo experiment, as well as an online example of 
the simulation output by pointing your web browsers at:

http://amethyst.cbs.ogi.edu/JSB/XOP_page.html

or, you can grab them via anonymous ftp at:

amethyst.cbs.ogi.edu
        in the directory pub/xop

The files are binhexed, self-extracting archives.

Let me know what you think...

Have a good day,
-John Boswell

*********************************************************************
Dr. John Boswell  Oregon Graduate Institute of Science and Technology
                        Department of Chemistry, Biochemistry, and
503-690-1086                    Molecular Biology       
                        PO BOX 91000, 20000 Walker Rd, Portland, OR
boswell@amethyst.cbs.ogi.edu or knight@grafton.dartmouth.edu

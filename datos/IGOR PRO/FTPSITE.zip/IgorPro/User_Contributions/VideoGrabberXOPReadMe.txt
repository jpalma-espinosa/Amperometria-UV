About Video Grabber XOP
Version 1.5 �  NL.1996-97

VG-XOP has the following features :
	- video monitor,
	- access to Apple's standard video settings dialog,
	- single frame grabbing ( control panel & external operation ).

With VG-XOP (Video Grabber XOP) you can grab a single frame 
from the onboard video input of the macintosh (or other hardware?)
and store it into an Igor's 2D wave, a PICT file or the clipboard.
VG-XOP adds a menu item in Igor's main menu bar and an external 
operation which name is"VideoCapture". Using the menu you can 
load/quit VG-XOP and access its features. "VideoCapture" can be 
called from an user procedure.

---------------------------------------------------------
VideoCapture [ /D ] [dest_waveName]

Flags 
	/D   creates a new graph and appends the matrix as an image.

Details
 	The size of the resulting image depends on the current size of the 
	video monitor(1/4, 1/2 or 1/1). If  "dest_waveName" is ommited
	a default wave name is used.    

Examples
										VideoCapture
          VideoCapture /D 
          VideoCapture /D  mydestWave.
---------------------------------------------------------

VG-XOP is :
	- a PPC ONLY XOP and has been tested on a 7500, a 7600 and 
			an 8500 Power Macintosh,
	- very easy to use,
	- FREE ! 

VG-XOP requires :
	- Igor 3.0 or later,
	- QuickTime 2.0 or later,
	- a (color or black&white) video source plugged in the Mac !

Have fun...

Nicolas Leclercq				
Laboratoire LURE				
Bat. 209D 					
Universite Paris-Sud
91405 Orsay Cedex.
email : leclercq@lure.u-psud.fr


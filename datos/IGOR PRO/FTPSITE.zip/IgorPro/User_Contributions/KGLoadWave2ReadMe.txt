New Version 2 of KGLoad.

This package is the compressed set of "KGLoad XOP2", that contains the
following files:
	KGLoad				IgorPro XOP to read from "KaleidaGraph" binary formatted file
	KGLoad Help			Help file
	
The contained version of KGLoad XOP is FAT binary.  It requires 68020 CPU
or higher, or any PowerPC CPU.  FPU is not required.

Slightly detail are written in "KGLoad Help" file.  If you want much more,
please contact
me by e-mail.
	yama@biotech.okayama-u.ac.jp
	
Please enjoy with it.

Mamoru Yamanishi
June 24, 1997.




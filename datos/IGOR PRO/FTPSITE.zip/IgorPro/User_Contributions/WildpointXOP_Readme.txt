The WildPoint XOP is a nonlinear filter designed to remove transient
events (wild points) from a wave. Conceptually the operation works by
creating a secondary array consisting of the output of a running median
filter of width filterWidth. That is, for each point, x[i], the points
x[i-filterWidth/2,i+filterWidth/2] are sorted and the median is selected.
Each data point is then compared with its corresponding median value.
If the data point differs from the median by a value exceeding the
threshold then that data point is replaced by NaN or the median value
itself if the /F flag is specified.

Both the XOP and all source code are included in the accompanying file.

The syntax is

WildPoint [/D/F] wave, filterWidth, threshold

where

   wave          specifies the wave to be edited. Wild point editing is done
                 in place, modifying the input wave. The input wavetype can
                 be either float or double.
   filterWidth   specifies the width of the median filter to be applied to
                 the data. In general, transients off less than filterWidth/2
                 in length will be eliminated by this routine. Those transients
                 longer than filterWidth/2 in length are unaffected.
   threshold     specifies an absolute numeric threshold for use in the
                 editing process. Those points that differ from the central
                 median by an amount exceeding threshold are identified as
                 wild points and edited out. Data points that are removed are
                 filled with NaN(0), unless you specify the /F flag.
Flags
   /D   Treat data as angle measured in degrees from 0 to 359. Prevents wrap
        around from 0 to 359 from being treated as a large jump.
   /F   Replace edited value with median value.

Wildpoint was created by:
   Rick Chapman
   Johns Hopkins University
   Applied Physics Laboratory
   Johns Hopkins Road
   Laurel, MD 20723
   PHONE: (301) 953-6000 x4209
   FAX: (301) 953-5548
   INTERNET: chapmnan@tesla.jhuapl.edu
   APPLELINK: BOOJUM

Comments, suggestions, or bug reports are welcome.
This XOP and its source code can be freely distributed. 

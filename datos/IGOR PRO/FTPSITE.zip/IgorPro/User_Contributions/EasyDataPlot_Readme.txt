EasyDataPlot Readme
--------------------------------------------------------------------------------
EasyDataPlot is a set of macros for Igor Pro which essentially presents students and 
Igor Pro novices with a simplified user interface. The macros will surely evolve as I 
get feedback from students who will use it this semester.

Thanks for downloading EasyDataPlot. I hope you find it useful. Please let me know if 
you do use these macros, by emailing me at

fjam@sunyit.edu

Perhaps several of us who use Igor Pro in the classroom can work together on these 
and similar projects.

-John
--------------------------------------------------------------------------------
Features  of EasyDataPlot include:

(1) Buttons on the main control panel are: "New Graph", Add to Graph", Erase from graph", 
Delete Graph", "Print Graph", "Change Axis Range", Change Colors", "Change Symbol", 
"View Next Graph", "Rename Data", "Set Units on Data", "Fit Data", "Apply Equation to 
Data", and "Make Evenly Spaced Data".

(2) All data is plotted in xy mode, and it's impossible to plot one wave vs another one 
of different length.

(3) The print graph button automatically makes a layout including an annotation giving 
the name of the user and the date.

(4) Linear and quadratic fits to the data are automatically annotated on the graph. The 
user can zap points from the fit using the Get Info cursors.

(5) Each plot has a legend telling *both* the x and y waves plotted (all plots are in xy 
mode).

--------------------------------------------------------------------------------

I also have one called EasyFunctionPlot which allows students to enter equations in and 
see them on the screen very easily. Automatically generated layout is printed showing 
user name and date. The printout has 6 individual plots of the functions plus a single 
plot containing all six. Students have found this very easy to use, and can investigate 
wave phenomina easily.

--------------------------------------------------------------------------------

I've also written a number of "interactive demos". One plus is that these can be run on 
the demo version of Igor Pro for free. Titles include: 1D-MOTION (const accel parameters 
set by students, also, students can draw the x-t wave with the mouse and v-t and a-t 
are calculated) PROJECTILE MOTION (4 trajectories plotted, has control panels for 
setting initial velocity and angle, or components of initial velocity), SOUND SYNTHESIS 
(control panels for viewing, synthesizing and playing a sound wave), FABRY PEROT 
INTERFEROMETER (shows  plot of output intensity, controls allow two different input 
wavelengths), RAY TRACING (draws spherical surfaces and traces rays through... 
especially useful to see aberrations), and MICHELSON INTERFEROMETER (shows radial 
plot of output as well as an image of circular fringes, control panels allow two input
 wavelengths).

I'm happy to share all these files with anyone interested.
---------------------------------------------------------
John A. Marsh                      Voice:    315-792-7395
Arts and Sciences                    Fax:    315-792-7503
SUNY Institute of Technology        Home:    315-733-5674
Utica, NY 13504-3050 USA           eMail: fjam@sunyit.edu
WWW: http://marsh.arsc.sunyit.edu/marsh/jmarsh.html
---------------------------------------------------------

Pack Igor Experiments

These are two scripts that use AppleScript to open old style Igor files,
with their associated folders, and save them in the new Igor Pro style
packed file.

Both of these scripts require that you have obtained and installed
AppleScript.  The script marked for systems 7.1.2 and later also assumes
the presence of a scriptable Finder.  A scriptable finder is included in
all Finders after System 7 Pro (AKA 7.1.1).  I have not tested this script
with System 7.5.

The script that uses the finder is a droppable script.  Drop a folder that
contains old-style Igor files (type "IGSU") on the script, along with
another *empty* folder to contain the new packed files.  That should be it.
Go and get a cup of coffee.  This script will also run if double-clicked.
You will then get two dialogs asking for source and destination folders.

The other script does not use the scriptable Finder.  As such it cannot
filter for a specific file type, nor can it work in the drop mode.  Run the
script and you are asked to choose a source and destination folder.  The
script will then attempt to convert all the files in that folder.  It will
assume that all folders have the name "Folder" in them (the Igor default)
and that all files are old style Igor files.  I have not tested this for
robustness, so take care to set things up as directed.

A final caveat.  I wrote these scripts as I am trying to learn AppleScript
and it seemed like a good exercise.  The kind folks at Wavemetrics have
tested them some, but neither I nor they can be responsible for adverse
outcomes.


             -Steve Rauseo (srauseo@david.wheaton.edu)
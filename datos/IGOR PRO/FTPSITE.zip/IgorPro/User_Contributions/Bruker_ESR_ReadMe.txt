Bruker_ESR.sit.hqx

I made an XOP for loading EPR spectra from Bruker's file.

Using my XOP, LoadBruker, you can load and/or transform your spectra
on IgorPro.

My develop/working environments are:

	PowerComputing PowerBASE 180 (603ev running at 180 MHz)
	MacOS 8.1 + Japanese language kit
	IgorPro 3.13
	MPW 3.5/MrC/SC
	
This XOP requires followings:

	Macintosh having 68020 CPU or later, or PowerMacintosh
	(FPU for 68K mac is not required, but highly recomended)
	
	IgorPro 3.0 or later for Macintosh
	
Current version contains two XOP; one, "LoadBruker XOP", is for
PowerMacintosh.  another, "LoadBruker 68K", is for 68K Macintosh.

You may use it freely.  If you find any bugs, please notice me by e-mail:
<mailto:yama@biotech.okayama-u.ac.jp>

Included "Help file" will give you slight more detail.

Please enjoy it.

Mamoru Yamanishi
Mar 20, 1999
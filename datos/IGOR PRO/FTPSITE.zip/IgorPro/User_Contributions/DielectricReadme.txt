Important Note: This program is FREE and can be redistributed without the
explicit written consent of the author for NON-COMMERCIAL PURPOSES ONLY.
The only restriction is that the whole package (including the Notebook file, 
Dielectric1.0.0b4_Info.ifn) should be distributed. It can be freely
modified but only the original version can be redistributed (exception: if
you explicitly indicate that you are distributing a modified version and
include the unmodified version as well as the Notebook file with it).

Wednesday, June 9, 1999
Information on Dielectric v1.0.0b4:

     Finally, the Macintosh and PC implementation of the Kramers-Kronig (KK)
program is working now. This is an official "release". This code was
formerly known as Kramers-Kronig which was never publicly distributed. As
the version number implies, this is a beta version. It works with Igor Pro
3.x. I haven't tested it with Igor Pro 2.0 but it should work with that as
well since I haven't  (I think) - used any new features of 3.0. I am not sure if
there are any differences between the FFT code of the Igor Pro 2.0 and 3.0,
but I think not. The documentation suggests that the new FFT code now allows
the use of non-power-of-two waves, but for normal (power-of-two) waves, the
results should be the same. Since, the routines used in this program
"require" the input files to have power-of-two dimensions, all should be fine.

Using Dielectric 1.0.0b4:
     
        The program really is a set of macros and functions. The macros
handle all the user interface while the functions do all the computations.
Change this {There are two macros: KK, Img2Real, SaveOrNoSave. The latter
are called by the first}. They are all invisible in the menu. The "Analysis"
menu shows an item called "Dielectric 1.0.0b4". To run the program just
select this item from the menu or use the keyboard shortcut Command-K. It's
only purpose is to display the program info, set up the "Main Panel" (where
user selects the operation/options etc) and print program identification in
the Command Window. This is also where the data files  are read in (if
necessary). Once there is some input data in memory, then Img2Real macro is
called. This latter macro, asks for a number of parameters to be put in
(self explanatory: maybe I'll describe the parameters some day for the
masses). Read the Notebook file, Dielectric1.0.0b4_Info.ifn for more info.
In the next release, I will include references to the method behind the
calculations and will include a demo experiment.

Then there are the functions sinft(), cosft() and invcosft(). These
are just my Igor implementations of the 'Numerical Recipes' codes. They, in
turn call the built-in FFT routine of Igor Pro. Unfortunately, FFT replaces
the 'real' input data wave with a complex array of half the size. So,
sinft() and cosft() reorganize the data into a 'pseudo-complex' real array
(i.e., a real array such that both real and imaginary components are
included in points n and n+1 etc).
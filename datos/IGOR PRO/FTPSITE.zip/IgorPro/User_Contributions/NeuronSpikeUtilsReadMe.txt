NeuronSpikeUtils.txt
=======================================================================
History: 
  Version 1.6 of SpikeUtils   (15 Oct 1998)
Data with seconds or milliseconds now supported.
Zipped archive included for Windows users.  Procedures NOT tested on windows.
Included file list in this file.
   Version (1.5) of SpikeUtils.
Help File: Totally changed. Lots of examples added.
Get Latencies: Option added to produce Inter Spike Interval waves
Build Histogram: Bug fixed that prevented some waves from being read.

Files:
NeuronSpikeUtils.txt:  This text file.
NeuronSpikeUtils.sea.hqx:  Macintosh binhex coded self extracting archive
NeuronSpikeUtils.PC.zip:   PC zipped file.
In archives are:
  NeilStringUtils:  										String functions used by SpikeUtils
	NeuronSpikeUtils Help File:		Igor Help File
	SpikeDemo															Demo experiment
	TriFilter																Mike Paulins triangular filter
	SpikeUtils															The core procedures
	NeuronSpikeUtils.txt							This file.

Routines:
Get Latencies: Produces ISI and Spike Frequency from raw spike train data.
Convert Latencies to Freq: Produces ISI and Spike Frequency from latency data.
Build Histogram: Accumulates latency data (e.g. from many trials) into single rate-histogram.
Plot Mean+-SD lines:  Superimposes error lines on whole trace. Errors derived from specified control period.
TriFilter:  Triangular filter suitable for spike rate estimations. Provide latency data - converts to filtered frequency data. (MG Paulin. Biol. Cybern. 1992 vol 66. 525-531)


If you use these procedures and find them useful, great.  If you improve them, send me the code to incorporate it.  Job offers graciously accepted. 
Thanks,  Neil Berman   nberman@uottawa.ca    University of Ottawa
========================================================================

This XOP was developed to control a Time Resolved Circular Dichroism spectrometer.It adds enough features to Igor to take control over a GPIB-Bus system. The functions included should be used as follows:

1. Create a macro StartUp().

2. In that macro create a variable that will from now on be the token to your device.

3. Do a call to FindGPIBDevice() like this:

	Macro StartUp()
		Variable myDevice
        myDevice = FindGPIBDevice( "issm");
	End

4. From now on whenever you do access a device use the variable created above like this.

	Function HiThereDevice()
		Print PingGPIBDevice( myDevice )
	End

or:

	Function SayHiToDevice()
		WriteToGPIBDevice( myDevice, "Hi there, how are you doing?" )
	End

Do so with the rest of all other functions.

ReadWaveFromGPIBDevice() and AddWaveFromGPIBDevice() expect binary 4-byte floats stored in the intel way. Binary is the fastest way of doing it. If you want to read in ASCII coded data use a construct like this:

	myWave = str2num( ReadStringFromGPIBDevice(myDevice, numFieldSize) )

This will call ReadStringFromGPIBDevice(myDevice, numFieldSize) for every wave-data-point. numFieldSize is an integer that should contain the length of the longest possible ASCII coded number. Some functions that come with this XOP do not contain any help in the Function Help Browser. These are for my special needs only and shouldnt be of any use for others. They control a  Stanford Research Systems Digital Delay Generator and a Chromex Spectrograph and a CCD Camera. These are specific functions designed to do complex communications with these listed devices.

To eliminate the Device Control... Menu just open the XOP with ResEdit, and delete the "XMN1" Resource. Done.

Stephan Wenzel

Wenzel@Uni-Duisburg.de

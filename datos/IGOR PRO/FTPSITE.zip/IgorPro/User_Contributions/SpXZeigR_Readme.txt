Date: Mon, 5 Jan 1998 10:15:55 -0800
To: Jim@wavemetrics.com
From: "Jeffrey J. Weimer" <jjweimer@matsci.uah.edu>

SpXZeigR is a collection of procedure files to analyze, manipulate, and
layout spectroscopic data in an efficient manner using Igor Pro. An update
to the SpXZeigR routines has been posted on the WaveMetrics ftp site at
http://www.wavemetrics.com/TechZone/ftpinfo.html. Further details of the
routines are provided at http://matsci.uah.edu/lmass/spxzeigr/.

The files:

	SpXZeigR21r.sea
	Version 2.1r of SpXZeigR for Igor Pro 2.x.

	SpXZeigR300.sea
	Version 3.0.0 of SpXZeigR for Igor Pro 3.x.

	SpXZeigRdocs.sea
	An html manual and tutorial for SpXZeigR.
	(The manual is also posted at http://matsci.uah.edu/lmass/spxzeigr/)

--
Jeffrey J. Weimer
Chemistry Department/Chemical & Materials Engineering Department
Materials Science Building 125, South Loop Road
University of Alabama in Huntsville,  Huntsville, AL    35899
phone:(205)890-6954  fax:(205)890-6349  http://matsci.uah.edu/~weimer/

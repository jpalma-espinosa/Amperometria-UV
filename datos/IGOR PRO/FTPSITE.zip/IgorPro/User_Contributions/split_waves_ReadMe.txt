Hello Igorians,

I just finish procedure to split waves.
Any comment is wellcome

"""""
Here is a part of the Help File

*       Splitting Waves
(cliquez ici pour la Version Franaise)

v1.0  Martin CANALS, 1996, CREGU
email : canals@cregu.cnrs-nancy.fr
adresse postale : BP 23, 54501 Vandoeuvre les Nancy Cedex, FRANCE
Written for IgorPro 3.0.  (Panels and DataFolders)
Use this package to split waves in smallest waves. This is useful when you
import data from a Database (like a Microsoft Excel sheet).
Let us consider 3 waves
hole    Depth    Temp
iso1-1  100     150
iso1-2  120     170
iso1-3  150     200
iso2-1  90      120
iso2-2  110     150
iso2-3  130     165
fly1-1  120     100
fly1-2  150     120
fly1-3  170     130
 ...
If you want to plot with different symbols iso data and fly data, you must
split the 3 waves in 6 smallest :
hole_iso  Depth_iso   Temp_iso  hole_fly   Depth_fly       Temp_fly
iso1-1     100         150        fly1-1    120             100
iso1-2     120         170        fly1-2    150             120
iso1-3     150         200        fly1-3    170             130
iso2-1      90         120
iso2-2     110         150
iso2-3     130          65

Place the procedure file "splitting" in the User Procedures folder in Igor
Pro and then insert the following line in the procedure window
#include "splitting"
The SplitWavesPanel is displayed by the splitWaves item in the Data Folder
Limitation : splitting is made only by reference to Text Waves, regarding
the n characters from the left.( n= 1, ...,8)


Martin CANALS
CENTRE DE RECHERCHES EN GEOLOGIE DES MATIERES PREMIERES MINERALES ET
ENERGETIQUES
3, rue du Bois de la Champelle
54500 Vandoeuvre
Tel : (33) 03 83 44 19 00
Fax : (33) 03 83 44 00 29
e-mail : canals@cregu.cnrs-nancy.fr

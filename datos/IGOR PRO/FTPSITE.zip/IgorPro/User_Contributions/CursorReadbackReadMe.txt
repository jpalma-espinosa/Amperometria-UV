=================================================
CursorReadback.sit.hqx	9 Apr 1999
Bela FARAGO - ILL - Grenoble <farago@ill.fr>

Procedure: CursorReadback

A little utility to read back data from your graph.
It was strongly inspirated by the "Hook Peak Place" demo from WM and
somewhat by the JEG Color Legend of  Jonathan Guyer.

So if you include it in your experiment it will add a Hierarchical menu to
the end of the Graph menu with 2 items "Start Cursor Reading" and "Stop
Cursor Reading"
As it is in the Graph menu it is enabled only when the 2D graph or and
Image is at the front.
"Start Cursor Reading" will add a line on the top of the Graph and
continously shows the x,y coordinates of the cursor (changes the cursor to
a cross thingy) calculating back the real x and y values from pixels.
If the Graph is an Image it shows x,y,z
Click on the graph will print x,y(,z) in the history area.

"Stop Cursor Reading" will remove this control area and return to normal
operation.

Side effects:
If you enabled it for more than one graph, they all show the same values.
(not much a problem as long as we have only one mouse attached to the
Mac...)
Might interfere with J.G-s Jeg Color Legend as it uses the same area to show
the information.
I did not try with multiple axis situation or Image+2DPlot+contour as I
wanted to avoid too much calculations in the functions to keep good
responsiveness.

That's all. Feel free to modify it, it is really short.

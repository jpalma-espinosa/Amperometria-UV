ClipImage and RowLesImage are procedures for manipulating images with IgorPro 3. 

 I wrote these procedures and functions for myself to manipulate images easily. ClipImage realizes to clip an image using a familiar mouse operation. LowResImage makes a image with a reduced resolution. It takes much time for a high resolution image to handle, for instance, filtering, FFT, etc. You can try any beforehand operations to the reduced resolution images to save time.
	When I wrote these procedures, I got some ideas from procedures in IgorPro 3.03 package.  Any bug reports are appreciated.
 Of course, these are free. However, Author dose not abandon any copyright of these procesures, macro, and functions. Author dose not warrant, guarantee, or make any representations regarding the use of the results of the use of them.

Author: Masashi Kiguchi, Ph.D.<kiguchi@harl.hitachi.co.jp>

preparation:
1. Move the 'ClipImage' file and the 'LowResImage' file into the 'Igor Procedures' Folder.
2. Run Igor 3.03. "Image' menu appears on the menu bar.
3. Load a sample image to be manipulated, which should be a monochromatic or a direct color image, for example, a Lena image from 'Image MagPhase Demo' in Contours & Images folder in Examples folder. Display the image.

ClipImage:
1. Click a target image and choose a 'ClipImage' item from the Image menu. A clip panel appears.
2. Define an region to clip in the target image by an usual mouse operation, i.e., clicking and dragging it to diagonally to frame the region of interest. Click a mouse button in the marquee and choose 'MarqueeCoords'. The coordinate values of the region are measured and displayed in the clip panel. When 'MarqueeCoords_square' is selected, a square area is defined. 
3. Dest Wave Name is a destination wave name, which is automatically named.
4. When the Draw Area checkbox is checked, the clipping area is displayed on the target image, whose color can be selected using a pull-down menu.
5. Click 'Clip' button.
6. The coordinate values to be clipped are preserved until new region is defined. 
7. If you change the clipping region without changing the Dest Wave Name, the wave is overwritten. You can manually rename the Dest Wave Name. When the 'ClipImage' item is chosen again from the Image menu, new name, which dose not conflict with exsiting waves, are defined automatically.

LowResImage:
1. Click a target image and choose a 'RowResImage' item from the Image menu. A RowRes panel appears.
2. Input the denominators to reduce the image resolution.
3. A destination wave is automatically named as 'target wave name-pixels x rows'. You can rename it, if you like.
4. Click LowRes button.



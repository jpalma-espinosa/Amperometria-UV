The TEK_load XOP allows Igor to load Textronix's (.WFM) files.
The (.WFM) is the internal format of the Textronix digitizing 
Oscilloscope TDS series. This XOP adds an operation which 
could be called from both a menu item and the command line.
The loaded wave will be automatically adjusted the scaling 
and the units. 

 As I made this XOP, I refered to the cnvrtwfm.c/cnvrtwfm.h 
sources from Textronix. They will help you to get more detailed 
 information from (.WFM) files.

 This XOP is Macintosh version only. Sorry!

I'm not sure this XOP will loads all the (.WFM) files or not.
It should be tested in many cases. If you find some trouble 
with this XOP, please report to me.

Koji Yamanaka
 kojiy@ppl.eng.osaka-u.ac.jp
10/20/98   
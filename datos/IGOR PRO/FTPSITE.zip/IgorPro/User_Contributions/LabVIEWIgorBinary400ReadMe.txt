LabVIEWIgorBinary400

Gary W. Johnson           Electronics Engineer
johnsong@llnl.gov         Lawrence Livermore National Laboratory
(925) 423-0156            P.O. Box 808, L-352
Fax (925) 422-6892        Livermore, CA 94551-0808


These LabVIEW 4 VIs read and save numeric arrays as Igor (Wavemetrics Corp.) binary-format
files. The Igor file version is 2, for use with Igor 1.2 or higher. The newer version 3 format,
featuring multiple waves in a single file, is not supported. All Vis are portable among all LabVIEW
platforms (Mac, Windows, Sun, HP, Concurrent) without modification. Data files written on one
platform are readable on any other platform. LabVIEW 4 or higher is required.

There are five VIs to write data: for single (SGL) and double-precision (DBL) floating point, and
for I8, I16, and I32 integer numbers. Read Igor Binary File reads all formats except complex.
All of Igor�s wave data features are supported ( including X and Y scaling and labels, and wave
notes). Full documentation of the data structures in this file format is available in Wavemetrics�
Technical Note 003, Igor Binary File Format.. Information is also available through the Get
I n f o ... command on each VI and through the Description... fields on each control, accessible
through the LabVIEW Help window. Note that complex waves are not supported.
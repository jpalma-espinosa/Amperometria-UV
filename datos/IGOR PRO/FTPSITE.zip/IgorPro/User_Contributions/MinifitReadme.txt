Minifit.sit.hqx					2 Sep 1999

MINIFIT (By Thomas Hwang <thwang@itsa.ucsf.edu>)

Department of Ophthalmology
Box 0730
University of California
San Francisco, CA  94143
--------------------------------------------------------------------
INTRODUCTION

This program uses an amplitude threshold algorithm to detect spontanoeous synaptic events recorded 
from neurons and then analyzes the kinetics of those events.  It is written for Igor Pro 3 or later.  
The algorithm and performance are described in the following reference:

	Hwang TN, Copenhagen DR.  "Automatic detection, analysis, and discrimination of 
	kinetically distinct spontaneous synaptic events."  J of Neuroscience Methods.
	
All the primary macros are listed under a user-defined menu named "Minifit".
To run the program, one must first open a graph containing the wave to be analyzed.
The wave scaling must start at time zero and have a deltax such that the units are in
seconds.  For example, for data acquired at 1 kHz, the sampling interval is 0.5 ms but
the wave must have a deltax of 0.0005 rather than 0.5.  Then, run the macro called 
"Mini_analysis."  The program will mark the start of each detected peak with a purple
right-side-up triangle, the peak with a purple circle, and the end with a purple upside-
down triangle.  Events fall into one of four categories:

	1) good peaks			isolated single events whose decays were fit well (R-squared 
							value greater than a selected cut-off - see below) with a 
							single or double exponential curve
	
	2) bad peaks			isolated single events whoe decays were not fit well or that 
							created an error during the fit for whatever reason.
						
	3) overlapped peaks		events that occur during the decay phase of the previous event
							or that have events on their decay phase.  This events are not used
							for kinetic analysis.  However, one can use the input parameter
							"overlap criteria" (see below) to allow large events that only have
							relatively small events riding on their decay to be kept for analysis.
							The small events, in this case, are then categorized as "possible peaks."
							
	4) possible peaks		secondary events that occur on the decay phase of a primary event that 
							were so small compared to the primary event that were ignored so that
							the primary event could be used for kinetic analysis
							
The total number of detected peaks is defined as the sum of the good peaks, the overlapped peaks, and 
the possible peaks.  Bad peaks are discounted.

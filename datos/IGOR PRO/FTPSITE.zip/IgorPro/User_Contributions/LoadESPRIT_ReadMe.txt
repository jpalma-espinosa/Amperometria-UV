�	LoadESPRIT XOP
LoadESPRIT is an external operation that loads JEOL Electron Spin Resonance (ESR) Spectrophotometer data 
into Igor waves.   Such data is made by "ESPRIT" data station, that files are so called "ESPRIT" data files.

Because ESPRIT data station is UNIX based workstation, it will be needed to use their files on Macintosh that 
apropriate data conversion.  Most easiest way to do is to transfer such files through network. 
 
To avoid lacking any characters and to transfer more than two files together, it will be suitable to use tar 
and compress.  Such operations are
	esprit> tar cvf hoge.tar foo1 foo2.....
	esprit> compress hoge.tar
on Macintosh side, there are several tools for decompressing "compress"ed and "tar" files.

LoadESPRIT is adds the following to Igor:
	A menu item, "Load ESPRIT DATA..." in the Load Waves submenu
	Two command line operations, "LoadESPRIT" and "ESPRITInfo"

"LoadESPRIT" command allow you to asscess most types of files.  However, on a certain definite position, 
the files to be loaded must contain the keyword ESPRIT.  LoadESPRIT detect whether it is the ESPRIT data 
file or not as reading this keyword.

To write this XOP, thanks to Mr. Yoshio SAKURAI at JEOL for giving me a lot of usefull information.

This XOP is copyrighted by Mamoru Yamanishi.  Please contact me by e-mail in case you want.
	yama@biotech.okayama-u.ac.jp
4/4/97
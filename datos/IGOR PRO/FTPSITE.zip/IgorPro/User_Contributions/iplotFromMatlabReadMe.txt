Date: Sat, 15 Jan 2000 14:41:57 -0600
From: Steve Lewis <sh1@howdy.wustl.edu>
Organization: Laboratory for Ultrasonics

Subject: Igor plots from matlab

iplotFromMatlab.zip contains four Matlab files that allow a Matlab user to
plot to Igor in Windows.  Two of them are used by me.
The other two may be of interest to you.

iplot.m  - this is the main plotting routine.  You call it with any
number of arguments.  The argumments occur in pairs.  The first of the
pair is a string or tag indicating what comes next.  The second in the
pair can be a number, a matrix, a string, or a cell array of strings,
depending on the tag.  It works a lot like setting the properties for
figures and other objects in matlab.  A complete list of tags is located
in the m-file.  Just type help iplot to see them.  IMPORTANT.  The same
function can also make the graph in Matlab.  The destination of the data
is controlled with the 'destination' tag.  Specifiy 'igor' or 'matlab'
to control which program makes the plot.

isendwave.m - this is the function that sends a wave from matlab to
igor.  It is called by iplot.  You can use if for other purposes if you
wish.  Originally this was a sub-procedure in iplot.m, but I took it so
I could work around a bug in igor or matlab (no sure where the bug
exists).  If you have a matrix with Nan or Inf values in them, then when
they get to Igor, they become 1's and -1's.  So isendwave, which should
have been only one line of code, suddenly becomes many more....

igorinit.m - can be used to initiate a DDE conversation with Igor

igorterm.m - can be used to terminate a DDE conversation with Igor.

examples of use

x=[1 2 3 4 5]';
y=x.^2;
iplot('xdata',x,'ydata',y);    % plots to matlab figure window
iplot('xdata',x,'ydata',y,'destination','igor'); % plots to igor

Make sure Igor is running before you call iplot.

You can also manually send waves to igor:

Suppose you have a matrix called 'x' in Matlab and wish to either create or overwrite the wave called 'ydata' in the current data folder in igor.  The following steps will allow you to do this:

ch = igorinit;
isendwave(ch,'ydata',x);
igorterm(ch);

Of course, you can leave the channel open and call isendwave as many times with as many waves as you wish before calling igorterm(ch).

Please let me know what you think about this code.  I hope it is useful
to you. Let me know if you run into any bugs, or you find it diffuicult
to use.

Steve

+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-
Stephen Lewis                           sh1@howdy.wustl.edu
Laboratory for Ultrasonics              http://ultrasonics.wustl.edu/
Department of Physics
Washington University
St. Louis, MO  USA

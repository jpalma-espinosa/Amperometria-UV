
xBit64   v2.03 README.
April 10, 1995
=================================================

xBit64.sit.hqx contains:
-----------------


"xBit64":  FAT IgorPro XOP file.  Provides 10 new external functions
(XFUNCs) to
	IgorPro running on PPC or 68k Macintoshes.
	
"macros-Bit64":   Procedure file.  Provide a few handy macros extending the
usefulness
	of the external functions.
	
"macros-Bit64 Demo Panel": 	Demonstration procedure file.

"Bit64 Tutorial":   IgorPro Notebook file. Step-by-step introduction to the
functions.
================================================

FUNCTIONS:
---------

The functions provided by xBit64 give IgorPro programmers bitwise access to
64-bit, double precision variables and wave elements.

They provide the following single bit operations:

SET
CLEAR
TEST

They provide the following bitwise operations on 64-bit masks:

AND
OR
EXCLUSIVE OR
DIFFERENCE
SET INCLUSION
SET EQUALITY
COMPLEMENT


=================================================

PURPOSE:
--------

We developed these functions in order to manage a number of "flags" applied
to large data sets.

Specifically, we collect chromatographic data.  For each sample, there are
a number
of compounds which may be detected.  Using xBit64, we can assign one flag
to each
compound.  Thus, if the "CFC-113" flag is set for a given sample, we know
that we
obtained a good value for that compound.  Other flags tell us the source of
each sample,
"Calibration", "Air", "Zero Air", etc...  Yet others store the state of
certain instrument
solenoid valves at sample time.

In post-processing, the flag wave becomes a data filter.  Using the "set
inclusion"
operation, for instance, the analyst can request all samples of "Air" which
contained
bad "CFC-113" data, and then look for sources of trouble.

=====================================================

By:
Tom Baring
tbaring@cmdl.noaa.gov

Contributed free of charge.  No warranty.  You accept all risk in using this
software.




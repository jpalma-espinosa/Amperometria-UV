ReadLecroyFiles() - An IGOR Pro 2 Macro

We have developed a "poor man's" (maybe "simple man's" is better) method for
getting LeCroy digital oscilloscope data into Igor. Specifically, the LeCroy
model 9350 series will write binary data to an IBM floppy (3.5'') which can
then be accessed by a DOS program supplied by LeCroy. The DOS software is
primitive and if you want to get the data to any serious plotting program
you have to save the data as a large ASCII text file. Imagine the fun you
can have with a couple of hundred ASCII files that might contain 10's of
thousands of 8-byte text words! We have written a simple Igor Macro which
reads the important header information and the binary data directly from the
IBM floppy using the GBLoadwave XOP. It will handle both 8 bit waveforms and
16 bit (processed) waveforms and prints out the most important scope
parameters in the Command Window. It only handles single-trigger waveforms
so will not handle "sequential" data. It was written with Igor Pro 2. It's
not as nice as a custom XOP, but it's reasonably fast and very easily
modified. The Macro is pretty simple to use. It asks you to first read-in a
LeCroy binary file and then asks for the name you want to give the Igor wave
which contains that data file. If you don't like the user interface, you can
easily modify it.

Charlie DeJoseph and Peter Bletzinger

U. S. Air Force Wright Laboratory
WL/POOD, Bldg. 450
Wright-Patterson, A.F.B. OH 45433-7919
dejosepc@debye.appl.wpafb.af.mil

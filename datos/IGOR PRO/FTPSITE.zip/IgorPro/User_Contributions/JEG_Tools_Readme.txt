JEG Tools
---------


JEG Image Tools
---------------
These packages consist of tools of use in viewing images and graphs. The name is largely historical; several packages are useful for traces in graphs.

JEG Color Legend (formerly "JEG Z-Legend")
------------------------------------------
Appends a live color bar to an image, indicating the data dimension.

JEG Image Statistics
-------------------
Calculates a number of commonly cited (and virtually meaningless) statistics for images, such as RMS and average roughness. Values are automatically updated on Marquee contents.

JEG Scale-Bar
-------------
Appends a "nice" scale-bar to an image or graph.

JEG Spectral Filter
-------------------
A rudimentary tool for spectral filtering of images (uses the FFT power spectrum to remove or focus on features of particular periodicity).

JEG Zoom Graph
--------------
Adds addtional routines to the marquee menu. The existing Expand and Shrink items don't do the right thing when there are multiple sets of axes in the plot (makes a mess of JEG Color Legend layouts). These items fix the discrepancies.


JEG Load Nanoscope
------------------

Loads, displays, and exports Nanoscope SPM images. Particularly tested with NSIII AFM images, but should work for others as well. Depends on JEG Image Tools, although it's separate, as it seems to be of more specific interest that the others.


JEG Text Tools
--------------
These are tools of use in processing strings:

JEG Extract Dimensions
----------------------
Converts a string consisting of a number and an SI prefixed unit into a number and the base unit, e.g., "3.4 nm" is broken to 3.4e-9 and "m".

JEG Keyword-Value
-----------------
Like WaveMetrics' Keyword-Value package, but allows specification of the field separator and record separator (rather than assuming ":" and ";").

JEG Strip Whitespace
--------------------
Removes whitespace (spaces, tabs, etc.). Caller configurable; you can make double-u's whitespace if you like.
LoadAxonBinaryFiles2.1.2

This macro allows Igor Pro users on either the MAC or Win95/98/NT platforms to
load Binary files created by the Axon Instruments PCLAMP and Axotape2
electrophysiology data acquisition software for wintel boxes.

Changes in v2.1.2
1) Adds a separate pull down menu.
2) Adds a Load Next ABF and Previous ABF files.
3) Adds 2 graph control buttons to the graphs created from the loaded data.   
The first kills the graph and the waves (YES, removes the waves from memory).  
The second removes the Controls from the graph (to avoid accidentally killing graphs you may 
want to keep).  These features facilitate "browsing" through many data files.  
A fourth Procedure under the ABF menu lets you add the two control buttons to a graph.

Version 2.1.1 included several improvements and bug fixes.
In particular...
-It now works fine on Win95 Machines

-It is now compatable with ABF format 1.5 which is used in PCLAMP 7
along with previous ABF versions (original was ABF 1.2)

-It now computes waveform scaling correctly for data acquired with gain
telegraphing between the amplifier (tested with Axopatch 200A) and the
digidata 1200 board.  Also accounts for programable gain on Digidata
board.

-Is now able to open the same file multiple times.  Macro assigns new
wave names to each trace read.  Scales and plots correctly.
- It now also checks for file version number and prints a warning and
aborts if trying to read a non-ABF file.

Notes on use:
- Requires "#include <Strings as Lists>"  at beginning of file.
-Running the Macro evokes the File Open dialog which on the Mac, is looking for
files of the type "BINA".  If your .DAT or .ABF are not of type BINA they won't
appear in the dialog box.  In Win95/NT all files appear so this is not an issue.

If your files have a different type (which is usually established during the
transfer of the file to the Mac) just substitute that file type for "BINA" in the
Macro line: Open /R/T="BINA"/M="Open an AxonBinary file" filenum

You can determine and (change) the file type by using a program like Find File
from Norton Utilities.  I use the program Fetch to ftp ABF files from the PC to
the Mac.  This program lets you automatically assign Creator and Filetypes to PC
files based on their extention.  I use Filetype=BINA and Creator=mdos. You can 
also use PC exchange to do the same thing if you move the ABF files via
floppy disk.
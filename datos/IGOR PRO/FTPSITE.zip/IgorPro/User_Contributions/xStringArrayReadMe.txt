
xStringArray    v2.03  README.                                   April 10, 1995
=================================================

xStringArray.sit.hqx contains:
-----------------


"xStringArray":  FAT IgorPro XOP file.  Provides 10 new external functions
(XFUNCs) and
	24 new external operations (XOPs)to IgorPro running on PPC or 68k Macintoshes.
	
"macros-String Array":   Procedure file.  Provide several handy macros
extending the usefulness of the external functions.
	
"macros-Learn String Array": 	Demonstration procedures used in conjunction with
	the tutorial.

"String Arrays Tutorial":   IgorPro Notebook file. Step-by-step introduction.

================================================

PURPOSE:
--------

String arrays simplify the development of Igor stationery projects.  They
are used as a tool for organization, allowing the IgorPro programmer
to invent consistent naming schemes, and manage large sets of data
programatically.

They are also useful in Igor's interactive environment.  Macros included in the
".sit" archive provide batch wildcard operations.  For instance, to make a graph
of every "CO2" wave, you could simple type this command:

    'batch ("WAVE", "display @",  "CO2*")'

To kill every window:

    'batch ("WIN", "doWindow /K @", "*")'

To print the name of every wave which contains two or more "X"'s,  and
their lengths:

    'batch ("WAVE", "print \"@\", numpnts (@)", "*X*X*")'

================================================


Comparison with previous version of xStringArray:
-------------------------------------

Several known problems corrected:
	1- Oversized strings (i.e., longer than 2048 characters) no longer crash
		Igor.  Rather, are silently truncated.
	2- Bogus "out of memory" error message corrected.
	3- Error in xsaRedim corrected.
	4- Command-Period now aborts xsaList.
	5- Parsing problems corrected.  Optional command flags handled correctly.
	
New Operations:
	1- Sorting string arrays: xsaSort, saSort, saRSort.
	2- Catalog of string arrays can be written to a string array:  xsaFromCat.
		
Compatibility:
	This version should drop right in, with no modifications to your functions
	or xops.

=================================================


By:
Tom Baring
tbaring@cmdl.noaa.gov

Contributed free of charge.  No warranty.  You accept all risk in using this
software.





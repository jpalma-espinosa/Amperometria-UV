ProgWinXOP.zip
ProgWinXOP.sit.hqx
ProgWinXOPSource.sit.hqx
ProgWinXOPSource.zip

Mon, 4 Oct 1999 10:24:15 -0700

Progress Window for Igor

ProgWin is an XOP (external operation) that allows you to create and
control a window with a progress bar, some text, and an optional
button.  ProgWin requires Igor Pro 3.00 or later. 

There are two great things about using this progress window in your Igor procedures:

1. The user can see how long something will take.

2. You can provide a clean way of aborting complicated procedures.

Number 1 is obvious, but let's look at number 2.  Normally, to abort
a procedure in progress, the user presses -period (on a Mac) or
clicks the "Abort" button (on Windows).  But if you have a
complicated system of procedure files that creates temporary waves or
messes with the data folder structure then it can leave a big mess
when someone aborts your procedure in the middle. Now you can use
ProgressWindow instead! A new era in Igor programming begins! (Yadda
yadda yadda...) 

For instructions refer to the online help, under the operation ProgressWindow. 

For examples, check out the ProgWin Demo.ipf procedure file.

ProgWin was written by 
Kevin Boyce     <mailto:Kevin.R.Boyce.1@gsfc.nasa.gov>
Jens Rumberg    <mailto:jens.rumberg@vuw.ac.nz>


//========================================================================================
//
//��
//�� These routines converted to Igor programming language by Patrick Groenestein
//�� <patg@sydney.dialix.com.au>
//�� January, 2000.
//�� 	P.G. - 24 Mar 2000. Matched DICOM 3.0 standard. Fixed endian handling.
//��	P.G. - 26 Mar 2000. Added scaling to displayed images. 
//��	P.G. - 29 Mar 2000. Added auto loading of the DICOM dictionary. 
//��
//�� This code is in the public domain.
//�� This code was laid out in a monospace font.
//�� Current version 2.1
//��
//�� DICOM dictionary available from
//�� 			ftp://zippy.nimh.nih.gov/pub/nih-image/documents/dicom-dict.hqx
//�� 
//�� Some of these routines were inspired by Pascal sources from:
//��
//��Dicom.p
//��  by: Jim Nash, Synergistic Research Systems (jim.nash@his.com)
//��  Reads and decodes the DICOM header so that NIH Image can
//��  import DICOM images. DICOM (Digital Imaging and Communications
//��  in Medicine) is a format popular in the medical imaging
//��  community. This code is in the public domain.
//��
//
//========================================================================================

The DICOM loading routines consist of:
	This README file
	PG_DICOMLoader.proc
	PG_DICOMLoader Help
	DICOM dictionary

The DICOM dictionary should be moved to a directory called 'User Procedures Data' in the 'User Procedures' directory of the 'Igor Pro' directory.  If it is found there the dictionary will be automatically loaded into the experiment if it is not found.  The 'DICOMLoader.proc' and 'PG_DICOMLoader Help' file should be moved into the 'User Procedures' directory and an alias or shortcut of the 'PG_DICOMLoader Help' moved to the 'Igor Help Files' directory in the main 'Igor Pro' directory.

When Igor is [re]launched The 'Load Waves' menu item of the 'Data' menu will contain a submenu called 'DICOM...'.  Select the Help item to read about the routines.

DICOM is a 'free form' protocol popular in medical circles for exchanging information.  It is concerned with the exchange of information between various vendors and users.  Since the DICOM 3.0 standard there is a formal layout for the file format, which older files did not have to follow (and were much more variable in their readability as a consequence).  There is no format as such: the standard only specifies how data elements are to be organised.  A lot of the most useful header elements are documented in the DICOM dictionary, but there are many vendor specific elements which are not so documented, and there is nothing to stop anyone defining their own header elements and contents.
 
There is no guaranteed content in a DICOM file, either: the data does not necessarily contain any images.

These vagaries accepted, most DICOM files do contain images, from such sources as computed radiography, CT, MRI, PET, or nuclear scans, and these routines can deal with them.

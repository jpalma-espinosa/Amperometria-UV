
PULSE loader is XOP for loading data from files created by HEKA PULSE
program into Igor waves. It also places information about loaded waves in
wave notes.

This version contains numerous bug fixes, improvements, new features. Also
includes help file now.

Vladimir Avdonin
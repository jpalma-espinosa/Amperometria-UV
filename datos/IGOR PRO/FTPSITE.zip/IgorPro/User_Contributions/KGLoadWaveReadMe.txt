This package is the compressed set of "KGLoadWave", that contains the following files:
	KGLoad					IgorXOP to read/write "KaleidaGraph" binary formatted file
	KGLoad Help				Help file
	KGLoad Help(text)		Help file (formatted text version)
	KGLoad.make			makefile of "KGLoad"
	KGLoad.h				include header file
	KGLoad.c				MPW C source code
	KGLoad.r				resource code
	KGLoad Help resources	resource for help
	
The contained version of "KGLoad" is for 68K version only, it requires up to 68020 cpu
but no FPU.  However, you can easily re-build other version of "KGLoad", such as FAT
version, PPC-only version, or 680x0+FPU version.  In those case, you must re-write
KGLoad.make file.

Slightly detail are written in "KGLoad Help" file.  If you want much more, please contact
me by e-mail.  My e-mail address is
	yama@radical.biotech.okayama-u.ac.jp
	
Please enjoy with it.

Mamoru Yamanishi
Dec. 19, 1996.

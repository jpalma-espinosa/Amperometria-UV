DL708_XOP.sit.hqx

I made a file-loader XOP, "LoadDL708 XOP, that make you to access 
wave/trace from YOKOGAWA DL/AR series oscilloscope.

This XOP requires followings:

	Macintosh, having 68020 or later CPU, or PowerMacintosh
	(on Macintosh, FPU is not requied but recomended)
	
	IgorPro 3.0 for Macintosh or later
	
My environments are:

	PowerComputing PowerBASE 180 (603ev running at 180 MHz)
	MacOS 8.1 + Japanese Language Kit
	IgorPro 3.13
	
Current version of LoadDL708 XOP is 1.4.1, and made as FAT-binary.
You may use it freely.  If you find any bugs, please notice me by e-mail:
<mailto:yama@biotech.okayama-u.ac.jp>

Included "Help file" will give you slight more detail.

Please enjoy it.

Mamoru Yamanishi
Mar 20, 1999
LabVIEW_to_IgorPro.sit.hqx contains:

AE LV to Igor.vi:
  This vi automatically transfers an array from LabVIEW
  to Igor Pro via a Igor binary format file written to
  disk.  Apple Events are used to command Igor Pro to
  load the wave from the file. 

  Before running this vi, Igor Pro must be open and
  the experiment must have a path defined to the same
  location used by LabVIEW to save the binary file.
  There must also be a procedure named "MyProc(wavename)".

AE From LV to Igor:
  A companion Igor Pro experiment, already set up
  properly with "MyProc(wavename)".

LabVIEW vi as Word doc:
  This Microsoft Word document briefly explains, with
  words and pictures, the use of the included LabVIEW
  vi and Igor Pro experiment. 

LabVIEW_to_IgorPro was provided by Mike Young.
The AE vi is based on previous work by Gary Johnson.

More LabVIEW-related files can be found in

<URL:ftp://d31rz0.stanford.edu/WaveMetrics/Igor/XOPs/User_Contributions/Labview/>
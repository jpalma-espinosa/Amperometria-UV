Data Folder Demo is an IGOR Pro 3 experiment that contains a tutorial on IGOR data folders. IGOR data folders are like Finder folders except that they store IGOR data (waves, numeric variables and string variables) in memory rather than files on disk.

This tutorial shows how to use data folders to deal with runs of data, where each run consists of a number of signals with the same names as the other runs.

To do the tutorial, just open the Data Folder Demo experiment file from IGOR.

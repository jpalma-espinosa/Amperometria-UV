The examples in this directory require Igor Pro 3.

Standard WaveMetrics examples are shipped in the Examples folder in your Igor Pro folder.

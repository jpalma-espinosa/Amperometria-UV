The procedure files in this directory require Igor Pro 2 or 3.

Igor Pro 2 files can be used in Igor Pro 2 or Igor Pro 3.

Igor Pro 3 files require Igor Pro 3.

See also the /WaveMetrics/Igor/Procedures directory. It contains procedure files that work with Igor 1.2 but usually can be used with Igor Pro also.

NOTE: THESE PROCEDURES ARE PROVIDED AS-IS!
      THEY ARE NOT NECESSARILY PRODUCTION QUALITY,
      AND HAVE MINIMAL, IF ANY, DOCUMENTATION.

Standard WaveMetrics procedures are shipped in the WaveMetrics Procedures folder in your Igor Pro folder. Other procedure files should be placed in the User Procedures folder in your Igor Pro folder.

There are a number of ways to use procedures in Igor Pro:

1. Copy and paste them into your Procedure window.

2. Use the Open File menu to open the file as a procedure window.

3. Include them in the current experiment by putting a #include statement in your main procedure window.

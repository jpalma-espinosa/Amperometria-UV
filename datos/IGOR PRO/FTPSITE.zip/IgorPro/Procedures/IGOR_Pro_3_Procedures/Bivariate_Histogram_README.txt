The Bivariate Histogram procedure will divide a graph into quadrants and
report the number of data points in each quadrant.  The divider can be
dragged to a new location, and the counts will update automatically.  A
subset of the data can be extracted from a quadrant for further analysis.

When the files are unpacked, drag the procedure file, called "Bivariate
Histogram" into the WaveMetrics Procedures folder.  Then double-click the
demo experiment.

The intent of the procedure is to reproduce the kind of analysis done in
flow cytometry, a technique common in immunology.  If you are an
immunologist, you may be interested in this procedure file.  If you know
any immunologists, please show it to them.

In fact, the procedures may be useful in other fields.  I would be quite
interested to know of any such applications.

Regards,
John Weeks

WaveMetrics, Inc.
Phone (503) 620-3001
Fax   (503) 620-6754
email   support@WaveMetrics.com

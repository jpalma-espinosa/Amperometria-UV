Global Fit procedure file and Global Fit Demo experiment

The Global Fit procedure file contains procedures to build an Igor Pro 3.0 control panel
that automates global analysis, fitting of a model curve to multiple data sets 
simultaneously.  Model parameters can be global (the same value for all data sets)
or local (individual value for each data set).

To try the Global Fit Demo, copy the Global Fit procedure file into the 
WaveMetrics Procedures folder.  Then launch Igor Pro 3.0 by double-clicking the
Global Fit Demo file.

If you have comments, suggestions, or find a problem, please send e-mail to
support@wavemetrics.com.
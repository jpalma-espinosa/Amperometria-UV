The Path Profile procedure file implements control panels to help extract
profiles from an image or contour plot.  It support two modes, arbitrary
path and perpendicular path.  

The perpendicular mode uses the cross-hair feature added in Igor Pro 3.01
to pick either a vertical or horizontal path for profiling.  The data might
be stacked spectra through time, and you want to display the intensity at
a single wavelength as it changes with time, or you wish to pick out one
spectrum at a particular time.

The arbitrary path mode uses a wave to define the path over which the
profile is made.  This is useful for making profiles perpendicular to 
some linear feature on a map, for instance.  It was done with geologists
and geophysicists in mind, but may be useful to others as well.

Put the procedure file in the Images and Contours folder inside the 
WaveMetrics Procedures folder in your Igor Pro folder.  Putting it
there will allow Igor Pro updaters to find the file and replace it with
updated versions when they come out.
SpecialFuncs is a package of external functions for IGOR Pro 2 or
IGOR Pro 3. It adds the following special functions: 

fresnelCos(x)
fresnelSin(x)
fresnelCS(x)
hermite(n, x)
hermiteGauss(n, x)
sphericalBessJ(n, x)
sphericalBessY(n, x)
sphericalBessJD(n, x)
sphericalBessYD(n, x)
dawson(x)
airyA(x)
airyAD(x)
airyB(x)
airyBD(x)
legendreA(n, m, x)
ei(x)
expInt(n, x)

Note: The sinc(x) function was removed from the SpecialFuncs XOP in
release 1.01 because it was added as a built-in function in IGOR Pro
3.02. 

The package is available via ftp from:
  <ftp://d31rz0.stanford.edu/WaveMetrics/IgorPro/XOPs/SpecialFuncs.sit.hqx>

Once you have unstuffed the file, drag the "SpecialFuncs" file and
the "SpecialFuncs Help" file into the "Igor Pro Folder:More
Extensions:Data Analysis" folder.

In the Finder, make an alias for the "SpecialFuncs" file and drag the
alias into the "Igor Pro Folder:Igor Extensions" folder. This
activates the extension.  

Now, double-click IGOR Pro to launch it. Then double-click the
"SpecialFuncs Help" file. This will give you a description of the
added functions. 

Next, double-click the "SpecialFuncs Demo" file to see some graphs
using the functions. 

The demo file requires IGOR Pro 3 and will not work with IGOR Pro 2. 

Howard Rodstein
WaveMetrics

sales@wavemetrics.com
support@wavemetrics.com
www.wavemetrics.com

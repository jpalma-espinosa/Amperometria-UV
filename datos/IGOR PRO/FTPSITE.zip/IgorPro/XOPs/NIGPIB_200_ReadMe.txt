NIGPIB 2.00 is an Igor Pro extension that allows you to control
National Instruments GPIB boards from Igor Pro. Version 2.00 adds
support for NI488.2 calls and runs on Windows as well as Macintosh.
This version will run with Igor Pro 3.0x or Igor Pro 3.1x or later. 


- Macintosh -
Put the NIGPIB and NIGPIB Help files in the "Igor Pro Folder:More
Extensions:Data Acquisition" folder. To activate NIGPIB, make an
alias from the NIGPIB file and put the alias in the "Igor Pro
Folder:Igor Extensions" folder and then restart Igor Pro. 

- Windows -
Put the NIGPIB.xop, NIGPIB Help.ihf, and NIGPIB Help.ihf.igr files in
the "Igor Pro Folder:More Extensions:Data Acquisition" folder. To
activate NIGPIB, make a shortcut from the NIGPIB.xop file and put the
shortcut in the "Igor Pro Folder:Igor Extensions" folder and then
restart Igor Pro. 

For NIGPIB documentation, see the NIGPIB Help file.

A GPIB-related technical note, Tech Note #019, is available from:
  <ftp://d31rz0.stanford.edu/WaveMetrics/IgorPro/Technical_Notes/>
This tech note was updated in December, 1997.

Howard Rodstein
WaveMetrics

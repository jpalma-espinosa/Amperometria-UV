DTGrabber

This XOP was developed in September-October of 1998 using version 2.03 Revision G of the Data Translation SDK.  It works with a board dated from the same era on a WIN95 platform.

It appears that the XOP does not work with a new board sold in February 1999 and with new sets of drivers.

For full details (rather amazing) contact ag@wavemetrics.com.


A.G.
WaveMetrics, Inc.

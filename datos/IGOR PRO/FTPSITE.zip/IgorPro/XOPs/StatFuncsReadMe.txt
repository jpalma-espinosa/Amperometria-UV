StatFuncs is an IGOR extension that adds statistical functions to
IGOR Pro 3. 

Put the StatFuncs file and the StatFuncs Help file in your "Igor Pro
Folder:More Extensions:Analysis" folder. To activate StatFuncs, make
an alias for the StatFuncs file and drag the alias into your "Igor
Pro:Igor Extensions" folder. Now, restart IGOR Pro. 

StatFuncs adds the following functions to IGOR Pro:
  pnoise(m)
  gammanoise(n)
  statTTest(type, wave1, wave2)
  statFTest(wave1, wave2)
  statChiTest(dataWave, expectedValuesWave, numConstraints)
  statPearsonTest(wave1, wave2, outputWave)

These functions are described in detail in the StatFuncs Help file.

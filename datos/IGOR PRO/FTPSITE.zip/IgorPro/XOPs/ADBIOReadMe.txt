The ADB I/O unit is a small, inexpensive data acquisition package
that connects to Macintoshes via the Apple Desktop Bus (ADB) port.
Briefly stated, it provides four relays and four I/O channels. The
I/O channels can be configured as analog inputs, digital inputs or
digital outputs. The unit is available from 

  BeeHive Technologies
  www.bzzzzzz.com
  818 304-0664

WaveMetrics is the creator of the IGOR Pro scientific graphing, data
analysis and automation program. 

WaveMetrics has created an ADBIO extension that allows IGOR Pro users
to control the ADB I/O unit from within IGOR Pro. The extension is
available in a package at the following URL: 
  <ftp://d31rz0.stanford.edu/WaveMetrics/IgorPro/XOPs/ADBIO1.0B01.sit.hqx>

The package contains the following files:
  ADB I/O             The IGOR Pro extension.
  ADB I/O Help     An IGOR Pro help file.
  ADB I/O Demo   An IGOR Pro "experiment" file that illustrates using the unit.

To try the package, you need an ADB I/O unit and IGOR Pro 2 or IGOR
Pro 3. If you do not have IGOR Pro, you can get a mostly-functional
demo from: 
  <ftp://d31rz0.stanford.edu/WaveMetrics/IgorPro/Demo/>

Once you have IGOR Pro, drag the "ADB I/O" file and the "ADB I/O
Help" file into the "Igor Pro Folder:More Extensions:Data
Acquisition" folder. In the Finder, make an alias for the "ADB I/O"
file and drag the alias into the "Igor Pro Folder:Igor Extensions"
folder. This activates the extension. Now, double-click IGOR Pro to
launch it. Then double-click the "ADB I/O Help" file. This will give
you a brief overview of the package. After reading the overview,
double-click the "ADB I/O Demo" file. 

Howard Rodstein
WaveMetrics

sales@wavemetrics.com
support@wavemetrics.com
www.wavemetrics.com

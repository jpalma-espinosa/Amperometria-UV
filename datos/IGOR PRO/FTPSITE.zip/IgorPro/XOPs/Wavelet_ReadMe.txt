Wavelet is a package containing 68K and PPC XOPs for performing
Wavelet transforms.  The XOPs require IGOR Pro 3.  

The package is available via ftp from:
  <ftp://d31rz0.stanford.edu/WaveMetrics/IgorPro/XOPs/Wavelet.sit.hqx>

Once you have unstuffed the file, drag the "Wavelet" file and the
"Wavelet Help" file into the "Igor Pro Folder:More Extensions:Data
Analysis" folder. In the Finder, make an alias for the "Wavelet" file
and drag the alias into the "Igor Pro Folder:Igor Extensions" folder.
This activates the extension. Now, double-click IGOR Pro to launch
it. Then double-click the "Wavelet Help" file. This will give you a
description of the added operations. Next, double-click the "Wavelet
Demo" file to see some graphs using Wavelet transforms. The demo file
requires IGOR Pro 3. 

AG
WaveMetrics

sales@wavemetrics.com
support@wavemetrics.com
www.wavemetrics.com

MLChartLoadWave is an external operation (XOP) that loads data from
MacLab Chart version 3.3 files into Igor waves. Chart is a program
produced by ADInstruments that works with their MacLab data
acquisition hardware. 

To use the XOP, you must drag the MLChartLoadWave file into the "Igor
Extensions" folder and then restart Igor. 

MLChartLoadWave adds a �Load Chart 3.3 File� item to Igor�s �Load
Waves� submenu. Choosing this displays the �Load Chart 3.3 File�
dialog. The dialog generates an MLChartLoadWave command which loads
data from the Chart 3.3 file. There is balloon help for the dialog.
Use the System 7 help menu to turn it on. 

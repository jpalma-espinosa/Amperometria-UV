Subject: New XOP: Load and Save *.wav files on Windows
Date: Thu, 8 Oct 1998 12:10:48 -0700
From: Jim Prouty <Jim@wavemetrics.com>
To: jimgate@wavemetrics.com

Windows users can now load and save *.wav sound files with Igor Pro
3.13 or later.

(Mac users have SndLoadWave which can read Mac sound files but, alas,
cannot save them.)

This very first release of the LoadWAVfile XOP loads most files
named something.wav into an Igor wave.

A Load WAV sound file item is added to the Load Waves submenu,
and a Save WAV sound file item is added to the Save Waves submenu.

Corresponding LoadWAVfile and SaveWAVfile operations are provided
with the traditional help file.

8-bit, 16-bit, mono, stereo, multi-channel sounds are supported.
Compressed sounds may be read, but only PCM (un-compressed) sounds
may be written.

Bugs and comments to jim@wavemetrics.com.




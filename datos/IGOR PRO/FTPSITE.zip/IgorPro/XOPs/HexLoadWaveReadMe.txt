HexLoadWave is an external operation that loads data from text files
containing hexadecimal numbers into Igor waves. 

HexLoadWave adds the following to Igor:

A menu item, Load Hexadecimal File in the Load Waves submenu.

A command line operation, HexLoadWave.

HexLoadWave files containing hex numbers which represent 8 bit, 16
bit, or 32 bit signed or unsigned integers and 32 or 64 bit IEEE
floating point numbers. For example, a file representing decimal
numbers 0 through 25 in five columns might look like this: 
	00	01	02	03	04
	05	06	07	08	09
	0A	0B	0C	0D	0E
	10	11	12	13	14
	15	16	17	18	19

HexLoadWave expects the file it is loading to contain a number of hex
numbers separated by a space, comma, tab, carriage return or any
other character that is not a legal hex character. 

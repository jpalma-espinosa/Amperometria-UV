Nicolas Leclercq, from the Universite Paris-Sud Laboratoire LURE, has
contributed a nifty XOP including source code that illustrates adding
a modeless dialog to IGOR Pro as well as a regular window (not a
dialog) containing controls. The source code may be of interest to
XOP programmers. 

The XOP and source code are available via ftp from:

<URL: ftp://d31rz0.stanford.edu//WaveMetrics/IgorXOPToolkit/User_Contributions/ModelessDLOG_XOP.sit.hqx>


The XOP requires IGOR Pro 3 and a PowerMac.

The source code requires IGOR XOP Toolkit 3.0 and CodeWarrior 9. To
compile the source, put the "ModelessDLOG XOP" folder in your
IgorXOPs folder, start CodeWarrior 9 or later, and click the compile
button. 

To run the XOP, drag the "ModelessWin PPC" file or an alias into the
IGOR Extensions folder and restart IGOR Pro. 

Nicolas Leclercq can be reached at:
   leclercq@lure.u-psud.fr

Howard Rodstein
WaveMetrics

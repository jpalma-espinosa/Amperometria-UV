The Absoft FORTRAN folder that accompanies this note contains source code,
libraries and a Read Me file for PowerMac FORTRAN versions of some of the
sample XOPs that come with the Igor External Operations Toolkit. Using the
Absoft FORTRAN PowerPC compiler in MPW, you can use these samples as a
starting point for your FORTRAN XOPs.

At present, developing Absoft FORTRAN XOPs for 680x0 machines is not supported.
The reason for this has to do with the fact that Absoft FORTRAN for 68K uses
MPW's "32-bit everything" runtime environment and this is not compatible with
Igor 1.2 or Igor Pro. In the future, it may be possible for us to support 68K
FORTRAN XOPs using a new runtime environment that Apple is developing.

Please address Igor and XOP-related questions to WaveMetrics and FORTRAN-specific
questions to Absoft.

WaveMetrics is grateful to Absoft for doing the C-to-FORTRAN translations
needed to provide this package.

Howard Rodstein
WaveMetrics

WaveMetrics:
	Tech Support: support@wavemetrics.com
	Sales Information: sales@wavemetrics.com
	Phone: 503-620-3001

Absoft:
	Tech Support: support@absoft.com
	Sales Information: sales@absoft.com
	Phone: 810-853-0050
	

TechGrapha is a font containing symbols useful for plotting data in
programs like DeltaGraph.  All of the basic symbols are constructed to
cover equal area.  The center of each character is the alignment point
for that symbol.

This package includes bitmap, type 1, and truetype files as well as the 
fontographer source.  The bitmaps are not cleaned-up, so you might want
to print a sample sheet to help you in selecting symbols.

TechGrapha is free.  If you like it please send a picture postcard to the
author at the address listed below.  You may distribute TechGrapha
provided you don't make money doing so and include all of its files.

Happy graphing...

Rob Kassel
MIT Spoken Language Systems Group
545 Technology Square Room 606
Cambridge, Mass.  02139
